#include <SPI.h>
#include <LoRa.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <DHT_U.h>

/* ==========================================
 * 1. KONFIGURASI PIN & PARAMETER
 * ========================================== */

// --- Konfigurasi LoRa (SPI) ---
#define ss 5               // Pin CS/NSS LoRa
#define rst 14             // Pin Reset LoRa
#define dio0 4             // Pin DIO0 LoRa (Aman, tidak bentrok dengan DHT)

#define LORA_FREQ 433E6 //Asia
// #define LORA_FREQ 866E6 //Europe
// #define LORA_FREQ 915E6 //North America
#define LORA_SYNC_KEY 0xF3 // Kunci sinkronisasi jaringan LoRa (Rentang: 0x00 - 0xFF)

// --- Konfigurasi Sensor Suhu & Kelembapan (DHT22) ---
#define DHTPIN 15          // Pin Data DHT22 (Aman, dipisah dari LoRa)
#define DHTTYPE DHT22
DHT_Unified dht(DHTPIN, DHTTYPE);

// --- Konfigurasi Sensor Hujan ---
#define POWER_PIN 32       // Pin untuk menyalakan/mematikan daya sensor hujan
#define AO_PIN 35          // Pin Analog untuk membaca sensor hujan
#define THRESHOLD_GERIMIS 3000
#define THRESHOLD_DERAS   1500

/* ==========================================
 * 2. VARIABEL GLOBAL
 * ========================================== */
uint32_t delayMS;          // Menyimpan jeda minimal pembacaan DHT22
int paketKe = 0;           // Penghitung jumlah paket yang dikirim

/* ==========================================
 * 3. FUNGSI SETUP (INISIALISASI)
 * ========================================== */
void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println(F("\n--- Inisialisasi Sistem Node Sensor ---"));

  // Inisialisasi Sensor Hujan
  analogSetAttenuation(ADC_11db);
  pinMode(POWER_PIN, OUTPUT);
  digitalWrite(POWER_PIN, LOW); // Pastikan daya sensor hujan mati di awal untuk cegah korosi

  // Inisialisasi Sensor DHT22
  dht.begin();
  sensor_t sensor;
  dht.temperature().getSensor(&sensor);
  delayMS = sensor.min_delay / 1000;
  if (delayMS < 2000) delayMS = 2000; // Pastikan jeda minimal 2 detik

  // Inisialisasi Modul LoRa
  LoRa.setPins(ss, rst, dio0);
  Serial.print(F("Memulai LoRa pada frekuensi "));
  Serial.print(LORA_FREQ / 1000000);
  Serial.println(F(" MHz..."));
  
  while (!LoRa.begin(LORA_FREQ)) {
    Serial.println(F("Gagal mendeteksi modul LoRa. Mengecek kabel..."));
    delay(1000);
  }
  
  // Menggunakan variabel key dari define di atas
  LoRa.setSyncWord(LORA_SYNC_KEY); 
  Serial.println(F("Inisialisasi LoRa OK!"));
  Serial.println(F("---------------------------------------\n"));
}

/* ==========================================
 * 4. LOOP UTAMA
 * ========================================== */
void loop() {
  // Tunggu sesuai jeda minimal sensor DHT22
  delay(delayMS); 

  // Variabel penampung data sementara
  float suhu = 0.0;
  float kelembapan = 0.0;
  int nilaiHujan = 0;
  
  // Penanda (flag) jika terjadi eror pada sensor
  bool erorSuhu = false;
  bool erorHujan = false;

  Serial.println(F("--- Membaca Sensor ---"));

  /* --- BACA SENSOR SUHU --- */
  sensors_event_t event;
  dht.temperature().getEvent(&event);
  if (isnan(event.temperature)) {
    Serial.println(F("Suhu         : Module suhu eror"));
    erorSuhu = true;
  } else {
    suhu = event.temperature;
    Serial.print(F("Suhu         : "));
    Serial.print(suhu);
    Serial.println(F(" °C"));
  }

  /* --- BACA SENSOR KELEMBAPAN --- */
  dht.humidity().getEvent(&event);
  if (isnan(event.relative_humidity)) {
    Serial.println(F("Kelembapan   : Module suhu eror"));
    erorSuhu = true; // Kita anggap satu kesatuan eror modul DHT
  } else {
    kelembapan = event.relative_humidity;
    Serial.print(F("Kelembapan   : "));
    Serial.print(kelembapan);
    Serial.println(F(" %"));
  }

  /* --- BACA SENSOR HUJAN --- */
  digitalWrite(POWER_PIN, HIGH);  // Nyalakan sensor hujan
  delay(10);                      // Tunggu tegangan stabil
  nilaiHujan = analogRead(AO_PIN); 
  digitalWrite(POWER_PIN, LOW);   // Matikan kembali agar tidak korosi

  if (nilaiHujan == 0) {
    Serial.println(F("Sensor Hujan : Module hujan eror"));
    erorHujan = true;
  } else {
    Serial.print(F("Sensor Hujan : "));
    Serial.print(nilaiHujan);
    
    // Tampilkan klasifikasi di Serial Monitor
    if (nilaiHujan > THRESHOLD_GERIMIS) Serial.println(F(" (Kering)"));
    else if (nilaiHujan < THRESHOLD_DERAS) Serial.println(F(" (Hujan Deras)"));
    else Serial.println(F(" (Gerimis)"));
  }

  /* --- KIRIM DATA VIA LORA --- */
  Serial.print(F("Mengirim Paket LoRa #"));
  Serial.println(paketKe);

  LoRa.beginPacket();
  
  // Format Payload yang dikirim: Suhu,Kelembapan,NilaiHujan
  
  // 1. Kirim data Suhu & Kelembapan
  if (erorSuhu) {
    LoRa.print("-99.9,-99.9,"); // Kirim nilai mustahil sebagai penanda eror ke Receiver
  } else {
    LoRa.print(suhu);
    LoRa.print(",");
    LoRa.print(kelembapan);
    LoRa.print(",");
  }

  // 2. Kirim data Hujan
  if (erorHujan) {
    LoRa.print("-1");          // Kirim -1 sebagai penanda modul hujan eror
  } else {
    LoRa.print(nilaiHujan);
  }
  
  LoRa.endPacket();

  // Tambah konter dan beri jarak antar pengiriman
  paketKe++;
  Serial.println(F("---------------------------------------\n"));
  
  // Jeda ekstra 3 detik agar modul LoRa tidak kelebihan beban (Duty Cycle)
  delay(3000); 
}