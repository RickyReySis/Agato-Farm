#define ENABLE_USER_AUTH
#define ENABLE_DATABASE

#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <FirebaseClient.h>
#include "time.h" // Library bawaan untuk waktu NTP

/* ==========================================
 * KONFIGURASI WIFI & FIREBASE
 * ========================================== */
#define WIFI_SSID "BSBAGATHO"
#define WIFI_PASSWORD "oregano28"
// #define WIFI_SSID "Xiaomi 14T Pro"
// #define WIFI_PASSWORD "Testcyborg"

#define API_KEY "AIzaSyBPUm8PeDCCkD337gsLMHPl61ea16A2bgQ"
#define USER_EMAIL "lora.farm1@mail.com"
#define USER_PASSWORD "Lora_Farm1"

#define DATABASE_URL "https://auto-farm-f0df3-default-rtdb.asia-southeast1.firebasedatabase.app/"

/* ==========================================
 * KONFIGURASI NTP (WAKTU WIB)
 * ========================================== */
const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 7 * 3600; // GMT+7 untuk WIB (7 jam x 3600 detik)
const int daylightOffset_sec = 0;

/* ==========================================
 * KONFIGURASI LORA & PIN
 * ========================================== */
#define ss 5 
#define rst 14 
#define dio0 4 

#define LORA_FREQ 433E6 
#define LORA_SYNC_KEY 0xF3 

// Threshold Hujan
#define THRESHOLD_GERIMIS 3000
#define THRESHOLD_DERAS   1500

/* ==========================================
 * OBJEK FIREBASE & NETWORK
 * ========================================== */
void processData(AsyncResult &aResult);
String getFormattedTime();

UserAuth user_auth(API_KEY, USER_EMAIL, USER_PASSWORD);
FirebaseApp app;
WiFiClientSecure ssl_client;
using AsyncClient = AsyncClientClass;
AsyncClient aClient(ssl_client);
RealtimeDatabase Database;

void setup() { 
  Serial.begin(115200); 
  while (!Serial); 

  Serial.println(F("\n======================================="));
  Serial.println(F("    LoRa Receiver + Firebase Starting  "));
  Serial.println(F("======================================="));

  // 1. Inisialisasi Wi-Fi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(300);
  }
  Serial.println("\nConnected! IP: " + WiFi.localIP().toString());

  // 2. Inisialisasi & Sinkronisasi Waktu NTP
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  Serial.print("Menyingkronkan waktu NTP");
  struct tm timeinfo;
  while (!getLocalTime(&timeinfo)) {
    Serial.print(".");
    delay(500);
  }
  Serial.println("\nWaktu tersinkronisasi: " + getFormattedTime());

  // 3. Konfigurasi Client SSL
  ssl_client.setInsecure();
  ssl_client.setConnectionTimeout(1000);
  ssl_client.setHandshakeTimeout(5);

  // 4. Inisialisasi Firebase
  initializeApp(aClient, app, getAuth(user_auth), processData, "🔐 authTask");
  app.getApp<RealtimeDatabase>(Database);
  Database.url(DATABASE_URL);

  // 5. Inisialisasi Modul LoRa 
  LoRa.setPins(ss, rst, dio0); 
  Serial.print(F("Menghubungkan LoRa ("));
  Serial.print(LORA_FREQ / 1000000);
  Serial.println(F(" MHz)..."));

  while (!LoRa.begin(LORA_FREQ)) { 
    Serial.println(F("Gagal deteksi modul LoRa! Cek kabel SPI.")); 
    delay(1000); 
  } 
  
  LoRa.setSyncWord(LORA_SYNC_KEY); 
  Serial.println(F("Inisialisasi LoRa OK!")); 
  Serial.println(F("Menunggu Data Masuk...\n"));
} 

void loop() { 
  app.loop();

  int packetSize = LoRa.parsePacket(); 
  
  if (packetSize) {     
    Serial.println(F("---------------------------------------"));
    int rssi = LoRa.packetRssi();
    Serial.print(F(">> Paket diterima (RSSI: "));
    Serial.print(rssi);
    Serial.println(F(")"));

    String LoRaData = "";
    while (LoRa.available()) { 
      LoRaData += (char)LoRa.read(); 
    } 
    Serial.print(F("Data Mentah CSV : "));
    Serial.println(LoRaData);

    // ==========================================
    // PARSING DATA CSV
    // ==========================================
    int firstComma = LoRaData.indexOf(',');
    int secondComma = LoRaData.indexOf(',', firstComma + 1);

    if (firstComma > 0 && secondComma > 0) {
      String tempStr = LoRaData.substring(0, firstComma);
      String humStr = LoRaData.substring(firstComma + 1, secondComma);
      String rainValStr = LoRaData.substring(secondComma + 1);
      String statusHujan = "";

      float tempVal = tempStr.toFloat();
      float humVal = humStr.toFloat();
      int rVal = rainValStr.toInt();

      bool isTempError = (tempStr == "-99.90" || tempStr == "-99.9");
      bool isHumError = (humStr == "-99.90" || humStr == "-99.9");

      if (rainValStr == "-1") {
        statusHujan = "EROR MODUL";
      } else {
        if (rVal > THRESHOLD_GERIMIS) statusHujan = "TIDAK HUJAN (Kering)";
        else if (rVal < THRESHOLD_DERAS) statusHujan = "HUJAN DERAS";
        else statusHujan = "HUJAN RINGAN / GERIMIS";
      }

      String waktuSekarang = getFormattedTime();

      Serial.print(F("Waktu        : ")); Serial.println(waktuSekarang);
      Serial.print(F("Suhu         : ")); Serial.println(isTempError ? "EROR" : String(tempVal) + " C");
      Serial.print(F("Kelembapan   : ")); Serial.println(isHumError ? "EROR" : String(humVal) + " %");
      Serial.print(F("Status Hujan : ")); Serial.println(statusHujan);

      // ==========================================
      // UPDATE DATA TERBARU DI FIREBASE (SET)
      // ==========================================
      if (app.ready()) {
        Serial.println(F("Mengupdate data di Firebase..."));

        object_t jsonObject;
        JsonWriter writer;

        object_t objTime, objSuhu, objHum, objHujan;

        writer.create(objTime, "timestamp", waktuSekarang);
        writer.create(objSuhu, "suhu", isTempError ? -99.9 : tempVal);
        writer.create(objHum, "kelembapan", isHumError ? -99.9 : humVal);
        writer.create(objHujan, "status_hujan", statusHujan);

        writer.join(jsonObject, 4, objTime, objSuhu, objHum, objHujan);

        // Menggunakan .set<object_t> ke path fixed (/sensor_data/latest)
        Database.set<object_t>(aClient, "/sensor_data/latest", jsonObject, processData, "RTDB_Set_SensorData");
      } else {
        Serial.println(F("⚠️ Firebase belum siap, data gagal dikirim."));
      }

    } else {
      Serial.println(F("⚠️ Format data LoRa tidak dikenali!"));
    }

    Serial.println(F("---------------------------------------\n"));
  } 
}

String getFormattedTime() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return "0000-00-00 00:00:00";
  }
  char timeStringBuff[30];
  strftime(timeStringBuff, sizeof(timeStringBuff), "%Y-%m-%d %H:%M:%S", &timeinfo);
  return String(timeStringBuff);
}

void processData(AsyncResult &aResult) {
  if (!aResult.isResult()) return;

  if (aResult.isEvent())
    Firebase.printf("Event task: %s, msg: %s, code: %d\n", aResult.uid().c_str(), aResult.eventLog().message().c_str(), aResult.eventLog().code());

  if (aResult.isDebug())
    Firebase.printf("Debug task: %s, msg: %s\n", aResult.uid().c_str(), aResult.debug().c_str());

  if (aResult.isError())
    Firebase.printf("Error task: %s, msg: %s, code: %d\n", aResult.uid().c_str(), aResult.error().message().c_str(), aResult.error().code());

  if (aResult.available())
    Firebase.printf("Task: %s, payload: %s\n", aResult.uid().c_str(), aResult.c_str());
}